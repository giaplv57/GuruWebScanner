<?php
    include ('include.php');
?>

<html>
    <div class="container-fluid">
        <br><br><br><br><br><br>
        <div class="box col-md-8 col-md-offset-2">
            <div class="col-md-12">
                <hr>
                <h2 class="intro-text text-center">Welcome to my world! <br>Try everything until you get the Flag!!!</h2>
                <hr>
                <br>
                <div class="col-md-8 col-md-offset-4">
                    <div class="col-md-2 col-md-offset-0 social-icons icon-circle icon-rotate">
                        <center>
                            <a href="./signIn.php"><i class="fa fa-sign-in fa-2x" style="color: rgba(0, 0, 0, 0.7);"></i></a>
                            <p style="color: rgba(0, 0, 0, 0.9); font-size: 13px;">Sign In</p>
                        </center>
                    </div>
                    <div class="col-md-2 col-md-offset-0 social-icons icon-circle icon-rotate">
                        <center>
                            <a href="./signUp.php"><i class="fa fa-user-plus fa-2x" style="color: rgba(0, 0, 0, 0.7);"></i></a>
                            <p style="color: rgba(0, 0, 0, 0.9); font-size: 13px;">Sign Up</p>
                        </center>
                    </div>
                </div>
            </div>
        
        </div>
    </div>
</html>